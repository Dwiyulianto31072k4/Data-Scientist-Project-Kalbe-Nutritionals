<?php
  $mysqli = new mysqli('localhost', 'root','','chatappslian');
  if( $mysqli->connect_error ){
    die('error');
  }
?>

